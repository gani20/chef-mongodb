name        "mongodb-replica"
description 'Cookbook for MongoDB Berkshelf based install'
maintainer  "Nicholas Valbusa"
license     "Apache 2.0"
version     "1.0.0"

depends 'mongodb'